// Vinicius de Jesus Alves de Andrade - RA 0026446
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "portuguese");

    int idade;
    float dias;

    printf("Qual a sua idade: ");
    scanf("%d", &idade);

    dias = idade * 365.25;

    printf("A sua idade em dias �: %.0f\n", dias);

    system("pause");
    
}
	
	
	
	
	
	
