// Vinicius de Jesus Alves de Andrade - RA 0026446
#include <stdio.h>
#include<stdlib.h>
int main() {
int i;

    printf("Numeros pares entre 1 e 50:\n");

    for (i = 1; i <= 50; i++) {
        
    
        if (i % 2 == 0) {
            printf("%d ", i); 
        }
    }

    printf("\n"); 
system("pause");
}

