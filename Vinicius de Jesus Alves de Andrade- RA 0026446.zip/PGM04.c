// Vinicius de Jesus Alves de Andrade - RA 0026446
#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {
    setlocale(LC_ALL, "portuguese");
float media, km, consumo;
printf("quantos km percorrido?");
scanf("%f", &km);
printf("o total de combustivel gasto?");
scanf("%f", &consumo);
media=km/consumo;
printf("O consumo total foi:%.2f\n", media);
system("pause");
}
