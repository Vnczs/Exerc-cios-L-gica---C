// Vinicius de Jesus Alves de Andrade - RA 0026446
#include <stdio.h>
#include<stdlib.h>
int main() {
    float numero;

    
    printf("Digite um numero: ");
    scanf("%f", &numero);

    
    if (numero > 0) {
        printf("O numero e POSITIVO.\n");
    } 
    else if (numero < 0) {
        printf("O numero e NEGATIVO.\n");
    } 
    else {
        printf("O numero e ZERO.\n");
    }

    system("pause");
    
}
