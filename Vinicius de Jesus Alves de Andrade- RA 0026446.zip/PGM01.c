// Vinicius de Jesus Alves de Andrade - RA: 0026446
#include <stdio.h>
#include <stdlib.h>

int main() {
    float din;

    printf("Quanto de dinheiro voce tem? ");
    scanf("%f", &din);

    if (din > 50) {
        printf("Amigao va ao cinema, voce esta RICO\n");
    } else {
        printf("Amigao fique em casa assistindo FAUSTAO\n");
    }
    system("pause");
    return 0;
}
