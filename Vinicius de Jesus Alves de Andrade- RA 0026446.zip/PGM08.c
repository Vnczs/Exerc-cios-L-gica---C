// Vinicius de Jesus Alves de Andrade - RA 0026446
#include <stdio.h>
#include<stdlib.h>
int main() {
	float n1, n2;
printf("Digite o primeiro numero:");
scanf("%f", &n1);
printf("Digite o segundo numero:");
scanf("%f", &n2);
if(n1>n2){
	printf("O primeiro numero (%.0f)e maior!\n", n1);
}
else if (n2>n1){

	printf("O segundo nuemro (%.0f) e  maior!\n", n2);
}
else{
	printf("Os numeros sao iguais!\n");
}
system("pause");
}
