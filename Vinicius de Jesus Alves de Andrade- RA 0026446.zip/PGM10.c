// Vinicius de Jesus Alves de Andrade - RA 0026446
#include <stdio.h>
#include<stdlib.h>
int main() {
int i;
for (i = 1; i <= 10; i++) {
        printf("%d\n", i);
    }
system("pause");
}
