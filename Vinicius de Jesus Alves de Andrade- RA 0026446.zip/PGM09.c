// Vinicius de Jesus Alves de Andrade - RA 0026446
#include <stdio.h>
#include<stdlib.h>
int main() {
	int numero;
	printf("Digite um numero:");
	scanf("%d", &numero);
	if (numero % 2 == 0){
		printf("O nuemero %d e PAR.\n", numero);
	}
	else{
		printf("O numero %d e IMPAR.\n", numero);
	}
	system("pause");
}
