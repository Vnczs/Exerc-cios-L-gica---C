// Vinicius de Jesus Alves de Andrade - RA 0026446
#include<stdio.h>
#include<stdlib.h>
int main (){
float area, raio;
printf("Digite o valor do raio:");	
	scanf("%f", &raio);
	area= 3.14 * (raio*raio);
	printf("O valor da area e: %.2f", area);
	system("pause");
	 
	
	
	
	
	
	
	
}
