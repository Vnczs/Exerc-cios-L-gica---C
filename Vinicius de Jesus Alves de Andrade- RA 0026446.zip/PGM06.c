// Vinicius de Jesus Alves de Andrade - RA 0026446
#include <stdio.h>
#include<stdlib.h>
int main() {
    float TA, TE, VP;
    printf("INSIRA O VALOR DA TAXA TA: ");
    scanf("%f", &TA);
    TE = 0.8 * TA;
    VP = TA + TE;
    printf("O VALOR A SER PAGO E: %.2f\n", VP);
    system("pause");
}
