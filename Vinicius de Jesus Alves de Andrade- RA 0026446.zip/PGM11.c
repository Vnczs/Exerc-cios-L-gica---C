// Vinicius de Jesus Alves de Andrade - RA 0026446
#include <stdio.h>
#include<stdlib.h>
int main() {
int N, i;
    int soma = 0; 

    printf("Digite um numero para N: ");
    scanf("%d", &N);

    for (i = 1; i <= N; i++) {
        soma = soma + i; 
    }

    printf("A soma de 1 ate %d e: %d\n", N, soma);
    
system("pause");

}
