// Vinicius de Jesus Alves de Andrade - RA 0026446
#include <stdio.h>
#include<stdlib.h>
int main() {
int num, i;

    printf("Digite um numero para ver a tabuada: ");
    scanf("%d", &num);

    printf("\n--- Tabuada de %d ---\n", num);
    
    for (i = 1; i <= 10; i++) {
        
        printf("%d x %d = %d\n", num, i, num * i);
    }
system("pause");


}
